<?php

session_start();
if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(16));
$CSRF = $_SESSION['csrf'];

const DB_HOST='127.0.0.1';
const DB_NAME='todo_db';
const DB_USER='root';
const DB_PASS='';
const DB_CHARSET='utf8mb4';

function pdo(): PDO {
  static $pdo=null;
  if ($pdo === null) {
    $dsn='mysql:host='.DB_HOST.';dbname='.DB_NAME.';charset='.DB_CHARSET;
    $pdo = new PDO($dsn, DB_USER, DB_PASS, [
      PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
      PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
      PDO::ATTR_EMULATE_PREPARES => false,
    ]);
  }
  return $pdo;
}

try {
  pdo()->exec("
    CREATE TABLE IF NOT EXISTS tarefas (
      id INT AUTO_INCREMENT PRIMARY KEY,
      title VARCHAR(255) NOT NULL,
      description TEXT NULL,
      due_date DATE NULL,
      due_time TIME NULL,
      done TINYINT(1) NOT NULL DEFAULT 0,
      created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
  ");
} catch (Throwable $e) {
  http_response_code(500);
  header('Content-Type: text/plain; charset=utf-8');
  echo 'Erro ao criar tabela: '.$e->getMessage();
  exit;
}

function json_response($ok, $data = [], $status = 200) {
  http_response_code($status);
  header('Content-Type: application/json; charset=utf-8');
  header('Cache-Control: no-store');
  echo json_encode(['ok'=>$ok] + $data, JSON_UNESCAPED_UNICODE);
  exit;
}

if (isset($_GET['ajax'])) {
  try {
    $action = $_GET['action'] ?? 'list';
    $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

    if (in_array($action, ['create','toggle','delete'], true)) {
      $token = $_POST['csrf'] ?? '';
      if (!hash_equals($_SESSION['csrf'], $token)) {
        json_response(false, ['error'=>'CSRF inválido'], 403);
      }
    }

    switch ($action) {
      case 'list': {
        $rows = pdo()->query("
          SELECT id, title, description, due_date, due_time, done, created_at
          FROM tarefas
          ORDER BY created_at DESC, id DESC
        ")->fetchAll();
        json_response(true, ['tasks'=>$rows]);
      }

      case 'create': {
        if ($method !== 'POST') json_response(false, ['error'=>'Método inválido'], 405);
        $title = trim((string)($_POST['title'] ?? ''));
        $desc  = trim((string)($_POST['description'] ?? ''));
        $due_date = trim((string)($_POST['due_date'] ?? ''));
        $due_time = trim((string)($_POST['due_time'] ?? ''));

        if ($title === '') json_response(false, ['error'=>'Título obrigatório'], 422);

        $due_date = $due_date !== '' ? $due_date : null;  
        $due_time = $due_time !== '' ? $due_time : null; 
        $st = pdo()->prepare("
          INSERT INTO tarefas (title, description, due_date, due_time)
          VALUES (?, ?, ?, ?)
        ");
        $st->execute([$title, $desc !== '' ? $desc : null, $due_date, $due_time]);
        json_response(true, ['message'=>'Tarefa criada']);
      }

      case 'toggle': {
        if ($method !== 'POST') json_response(false, ['error'=>'Método inválido'], 405);
        $id   = (int)($_POST['id'] ?? 0);
        $done = (int)($_POST['done'] ?? 0) ? 1 : 0;
        $st = pdo()->prepare("UPDATE tarefas SET done=? WHERE id=?");
        $st->execute([$done, $id]);
        json_response(true, ['message'=>'Status atualizado']);
      }

      case 'delete': {
        if ($method !== 'POST') json_response(false, ['error'=>'Método inválido'], 405);
        $id = (int)($_POST['id'] ?? 0);
        $st = pdo()->prepare("DELETE FROM tarefas WHERE id=?");
        $st->execute([$id]);
        json_response(true, ['message'=>'Tarefa excluída']);
      }

      default:
        json_response(false, ['error'=>'Ação inválida'], 400);
    }
  } catch (Throwable $e) {
    json_response(false, ['error'=>$e->getMessage()], 500);
  }
  exit;
}
?>
<!doctype html>
<html lang="pt-br">
<head>
  <meta charset="utf-8">
  <title>Lista de Tarefas — PHP + PDO + Ajax</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Bootstrap + Icons -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
  <style>
    body{background:#f4f6f9}
    .navbar{box-shadow:0 1px 2px rgba(0,0,0,.08)}
    .card{border:0;box-shadow:0 .25rem .5rem rgba(0,0,0,.08)}
    .done td{ color:#6c757d; text-decoration:line-through }
    .badge-rounded{ border-radius:1rem }
    .badge-overdue{ background:#dc3545 }
    .badge-soon{ background:#ffc107; color:#000 }
  </style>
</head>
<body>
<nav class="navbar navbar-dark bg-dark">
  <div class="container">
    <span class="navbar-brand"><i class="bi bi-check2-square me-2"></i>Lista de Tarefas</span>
    <span class="text-white-50 small"></span>
  </div>
</nav>

<div class="container my-4">
  <div class="row g-3">
    <!-- Formulário -->
    <div class="col-lg-4">
      <div class="card">
        <div class="card-header"><b>Nova tarefa</b></div>
        <div class="card-body">
          <form id="form-create" class="needs-validation" novalidate>
            <input type="hidden" name="csrf" value="<?=htmlspecialchars($CSRF)?>">
            <div class="mb-2">
              <label class="form-label">Título *</label>
              <input name="title" class="form-control" required placeholder="Ex.: Estudar PDO">
              <div class="invalid-feedback">Informe um título.</div>
            </div>
            <div class="mb-3">
              <label class="form-label">Descrição</label>
              <textarea name="description" rows="3" class="form-control" placeholder="Detalhes (opcional)"></textarea>
            </div>

            <div class="row g-2">
              <div class="col-6">
                <label class="form-label">Data (prazo)</label>
                <input type="date" name="due_date" class="form-control">
              </div>
              <div class="col-6">
                <label class="form-label">Horário</label>
                <input type="time" name="due_time" class="form-control">
              </div>
            </div>

            <button class="btn btn-primary w-100 mt-3">
              <i class="bi bi-save me-1"></i> Cadastrar
            </button>
          </form>
        </div>
      </div>

      <div class="card mt-3">
        <div class="card-body d-flex gap-3">
          <span class="badge text-bg-secondary badge-rounded" id="b-total">0</span> total
          <span class="badge text-bg-success badge-rounded" id="b-done">0</span> concluídas
          <span class="badge text-bg-warning text-dark badge-rounded" id="b-open">0</span> pendentes
        </div>
      </div>
    </div>

    <!-- Lista -->
    <div class="col-lg-8">
      <div class="card">
        <div class="card-header d-flex align-items-center justify-content-between">
          <b>Tarefas</b>
          <div class="input-group" style="max-width:420px;">
            <span class="input-group-text"><i class="bi bi-search"></i></span>
            <input id="filter" class="form-control" placeholder="Filtrar por título/descrição/prazo...">
          </div>
        </div>
        <div class="table-responsive">
          <table class="table table-hover align-middle mb-0">
            <thead class="table-light">
              <tr>
                <th style="width:70px">#</th>
                <th>Título</th>
                <th>Descrição</th>
                <th style="width:200px">Prazo</th>
                <th style="width:130px">Status</th>
                <th class="text-end" style="width:150px">Ações</th>
              </tr>
            </thead>
            <tbody id="tbody"></tbody>
          </table>
        </div>
      </div>
      <p class="text-muted small mt-2">Dica: tarefas vencidas aparecem com indicativo em vermelho.</p>
    </div>
  </div>
</div>

<script>
const CSRF = <?=json_encode($CSRF)?>;
const $ = s => document.querySelector(s);
let TASKS = [];

async function api(action, payload = {}, method = 'GET') {
  const url = '?ajax=1&action=' + encodeURIComponent(action);
  const opts = { method };
  if (method === 'POST') {
    const fd = new FormData();
    for (const [k, v] of Object.entries(payload)) fd.append(k, v);
    opts.body = fd;
  }
  const res = await fetch(url, opts);
  const text = await res.text();
  let data;
  try { data = JSON.parse(text); } catch(e) {
    throw new Error('Resposta não-JSON do servidor:\n' + text);
  }
  if (!data.ok) {
    throw new Error(data.error || ('Falha HTTP ' + res.status));
  }
  return data;
}

function escapeHtml(s){
  return String(s).replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
}
function fmtPrazo(due_date, due_time){
  if (!due_date && !due_time) return '<span class="text-muted">—</span>';
  const dd = due_date || '';
  const tt = due_time || '';
  // Formato BR simples
  let br = dd ? dd.split('-').reverse().join('/') : '';
  if (tt) br = br ? (br + ' ' + tt.substring(0,5)) : tt.substring(0,5);
  return br;
}
function isOverdue(t){
  if (Number(t.done) === 1) return false;
  if (!t.due_date) return false;
  const now = new Date();
  const yyyy = Number(t.due_date.substring(0,4));
  const mm   = Number(t.due_date.substring(5,7)) - 1;
  const dd   = Number(t.due_date.substring(8,10));
  let hh = 23, mi = 59; 
  if (t.due_time && t.due_time.length >= 5) {
    hh = Number(t.due_time.substring(0,2));
    mi = Number(t.due_time.substring(3,5));
  }
  const prazo = new Date(yyyy, mm, dd, hh, mi, 0);
  return now > prazo;
}
function isSoon(t){
  if (Number(t.done) === 1) return false;
  if (!t.due_date) return false;
  const now = new Date();
  const yyyy = Number(t.due_date.substring(0,4));
  const mm   = Number(t.due_date.substring(5,7)) - 1;
  const dd   = Number(t.due_date.substring(8,10));
  let hh = 23, mi = 59;
  if (t.due_time && t.due_time.length >= 5) {
    hh = Number(t.due_time.substring(0,2));
    mi = Number(t.due_time.substring(3,5));
  }
  const prazo = new Date(yyyy, mm, dd, hh, mi, 0);
  const diffMs = prazo - now;
  const umDia = 24*60*60*1000;
  return diffMs > 0 && diffMs <= umDia;
}

function render(){
  const fil = ($('#filter').value || '').toLowerCase();
  const rows = TASKS.filter(t => {
    const blob = `${t.title} ${t.description||''} ${t.due_date||''} ${t.due_time||''}`.toLowerCase();
    return !fil || blob.includes(fil);
  });

  const total = TASKS.length;
  const done  = TASKS.filter(t => Number(t.done) === 1).length;
  $('#b-total').textContent = total;
  $('#b-done').textContent  = done;
  $('#b-open').textContent  = total - done;

  $('#tbody').innerHTML = rows.map(t => {
    const badgeStatus = Number(t.done) === 1
      ? '<span class="badge text-bg-success">Concluída</span>'
      : '<span class="badge text-bg-warning text-dark">Pendente</span>';

    let prazoBadge = '';
    if (isOverdue(t)) prazoBadge = ' <span class="badge badge-overdue ms-1">Vencida</span>';
    else if (isSoon(t)) prazoBadge = ' <span class="badge badge-soon ms-1">Vence em 24h</span>';

    return `
      <tr class="${Number(t.done)===1 ? 'done' : ''}">
        <td>${t.id}</td>
        <td>${escapeHtml(t.title)}</td>
        <td>${escapeHtml(t.description || '')}</td>
        <td>${fmtPrazo(t.due_date, t.due_time)}${prazoBadge}</td>
        <td>${badgeStatus}</td>
        <td class="text-end">
          <button class="btn btn-sm ${Number(t.done)===1 ? 'btn-outline-secondary' : 'btn-success'} me-1"
                  onclick="toggleTask(${t.id}, ${Number(t.done)===1 ? 0 : 1})" title="Alternar status">
            <i class="bi ${Number(t.done)===1 ? 'bi-arrow-counterclockwise' : 'bi-check2'}"></i>
          </button>
          <button class="btn btn-sm btn-outline-danger"
                  onclick="delTask(${t.id})" title="Excluir">
            <i class="bi bi-trash"></i>
          </button>
        </td>
      </tr>`;
  }).join('');
}

async function load(){
  const { tasks } = await api('list');
  TASKS = tasks;
  render();
}

$('#form-create').addEventListener('submit', async (e) => {
  e.preventDefault();
  const fd = new FormData(e.target);
  const payload = Object.fromEntries(fd.entries());
  payload.csrf = CSRF;
  try {
    await api('create', payload, 'POST');
    e.target.reset();
    e.target.classList.remove('was-validated');
    await load();
  } catch (err) {
    alert(err.message);
  }
});

$('#filter').addEventListener('input', render);

async function toggleTask(id, done){
  try {
    await api('toggle', { id, done, csrf: CSRF }, 'POST');
    await load();
  } catch (err) {
    alert(err.message);
  }
}
async function delTask(id){
  if (!confirm('Excluir esta tarefa?')) return;
  try {
    await api('delete', { id, csrf: CSRF }, 'POST');
    await load();
  } catch (err) {
    alert(err.message);
  }
}

load();
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
